import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon

#KinoKiste - by Christof Torres 2011.

addon = xbmcaddon.Addon(id='plugin.video.kinokiste')
path = addon.getAddonInfo('path')+'/resources/art/'

def CATEGORIES():
        addDir('Aktuelle Kinofilme','http://www.kinokiste.com/aktuelle-kinofilme/',1,path+'/aktuelle-kinofilme.jpg')
        addDir('Neue Filme','http://www.kinokiste.com/neue-filme/',2,path+'/neue-filme.jpg')
        addDir('Serien','http://www.kinokiste.com/serien/',3,path+'/serien.jpg')
        addDir('Blockbuster','http://www.kinokiste.com/blockbuster/',4,path+'/blockbuster.jpg')
        addDir('Filme A-Z','http://www.kinokiste.com/film-index/',5,path+'/film-index.jpg')
        addDir('Genres','http://www.kinokiste.com',6,path+'/genres.jpg')
        addDir('Suche','http://www.kinokiste.com/?q=',7,path+'/suche.jpg')
                        
def INDEX(url):
        main_url = url
        req = urllib2.Request(main_url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        menu=url[24:len(url)]
        pages=re.compile('&nbsp;</a><a href="'+menu+'(.+?)/"').findall(link)
        pages = int(pages[0])
        for i in range(1, (pages+1)):
            page_url = main_url+str(i)+'/'
            req2 = urllib2.Request(page_url)
            req2.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response2 = urllib2.urlopen(req2)
            link2=response2.read()
            response2.close()
            match=re.compile('class="cover">\n\t\t<a href="(.+?)" title=".+?"><img src="(.+?)" alt="" width="160" height="143" border="0" alt="(.+?)" />').findall(link2)
            for url,thumbnail,name in match:
                url = 'http://www.kinokiste.com'+url
                req3 = urllib2.Request(url)
                req3.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response3 = urllib2.urlopen(req3)
                link3=response3.read()
                response3.close()
                match2=re.compile('<div class="cover"><img src="(.+?)"').findall(link3)
                thumbnail = 'http://www.kinokiste.com'+match2[0]
                year=re.compile('Jahr: <span style=".+?">(.+?)</span>').findall(link3) 
                name = name[0:len(name)-25]+' ('+year[0]+')'
                if (menu == '/aktuelle-kinofilme/') or (menu == '/neue-filme/') or (menu == '/blockbuster/'):
                        addDir(name,url,10,thumbnail)
                else:
                        addDir(name,url,8,thumbnail)

def ALPHABETICINDEX(url):
        for index in '1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z':
            index_url = url+index+'/'
            addDir(index,index_url,10,path+'/'+index+'.jpg')

def GENRESINDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()

        match=re.compile('<li><a href="(.+?)" title=".+?">(.+?)</a></li>').findall(link)
      
        for link,genre in match:
            if ((link != '/film-index/') and (link != '/film-updates/') and (link != '#')):
                genre_url = url+link
                addDir(genre,genre_url,13,path+'/genre.jpg')

def SEARCH(url):
        kb = xbmc.Keyboard('', 'Search www.kinokiste.com', False)
        kb.doModal()
        if (kb.isConfirmed()) and (kb.getText() != ''):
                search = kb.getText()
                search = search.replace(" ", "+")

                req = urllib2.Request(url+search)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()

                match=re.compile('<div class="moviename"><a href="(.+?)" title=".+?">(.+?)</a></div>').findall(link)

                for url,name in match:
                    url = 'http://www.kinokiste.com'+url

                    req2 = urllib2.Request(url)
                    req2.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                    response2 = urllib2.urlopen(req2)
                    link2=response2.read()
                    response2.close()

                    match2=re.compile('<div class="cover"><img src="(.+?)"').findall(link2)
                    thumbnail = 'http://www.kinokiste.com'+match2[0]
                    year=re.compile('Jahr: <span style=".+?">(.+?)</span>').findall(link2) 
                    name = name+' ('+year[0]+')'
                    
                    addDir(name,url,10,thumbnail)
        
def SEASON(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close() 
        match=re.compile('value="(.+?)">Staffel .+?</option>').findall(link)
        for name in match:
                name = 'Staffel '+name
                addDir(name,url,9,path+'/staffel.jpg')

def EPISODE(url,name):
        url = url+'?season='+name[8:len(name)]
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('value="(.+?)">Episode .+?</option>').findall(link)
        for number in match:
                name = 'Episode '+number
                SERIELINKS(url+'&episode='+number, name)

def VIDEOLINKS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        
        submenu=re.compile('<a class="submenu" href="#" onclick="(.+?);">(.+?)</a></li>').findall(link)
        if (len(submenu) > 0):
                for host,part in submenu:
                        host = host[host.find('(')+1:host.find(')')]
                        stream = url[0:24]+'/stream/'+url[25:len(url)]+'?h='+host
                        
                        req2 = urllib2.Request(stream)
                        req2.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                        response2 = urllib2.urlopen(req2)
                        link2=response2.read()
                        response2.close()

                        match2=re.compile('<iframe src="(.+?)"').findall(link2)

                        for eco_url in match2:
                            eco_url = eco_url[0:len(eco_url)-20]+'ss=1'
                            eco_url = eco_url[0:23]+'/stream/'+eco_url[30:len(eco_url)]
                            
                            req3 = urllib2.Request(eco_url)
                            req3.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                            response3 = urllib2.urlopen(req3)
                            link3=response3.read()
                            response3.close()
                                
                            match3=re.compile("var t=setTimeout\(\"lc\('([^']+)','([^']+)','.+?','.+?'\)\",(.+?)\);").findall(link3)
                                
                            for s,k,t in match3:
                                next_url = 'http://www.ecostream.tv/object.php?s='+s+'&k='+k+'&t='+t
                                
                                req4 = urllib2.Request(next_url)
                                req4.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                                response4 = urllib2.urlopen(req4)
                                link4=response4.read()
                                response4.close()
                                
                                match4=re.compile('<param name="flashvars" value="file=(.*?)&').findall(link4)
                                if (match4[0].find('%') != -1):
                                    match4[0] = match4[0][0:match4[0].find('%')]
                                addLink(part,match4[0],path+'/ecostream.jpg')
        else:
            match=re.compile('<div class="embedplayer">\n\t\t\t\t\t<a href="(.+?)" target="_blank">').findall(link)
        
            for eco_url in match:
                eco_url = eco_url[0:len(eco_url)-20]+'ss=1'

                req2 = urllib2.Request(eco_url)
                req2.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response2 = urllib2.urlopen(req2)
                link2=response2.read()
                response2.close()

                match2=re.compile("var t=setTimeout\(\"lc\('([^']+)','([^']+)','.+?','.+?'\)\",(.+?)\);").findall(link2)

                for s,k,t in match2:
                    next_url = 'http://www.ecostream.tv/object.php?s='+s+'&k='+k+'&t='+t

                    req3 = urllib2.Request(next_url)
                    req3.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                    response3 = urllib2.urlopen(req3)
                    link3=response3.read()
                    response3.close()

                    match3=re.compile('<param name="flashvars" value="file=(.*?)&').findall(link3)
                    if (match3[0].find('%') != -1):
                        match3[0] = match3[0][0:match3[0].find('%')]
                    addLink(name,match3[0],path+'/ecostream.jpg')

def SERIELINKS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()

        match=re.compile('<iframe src="(.+?)"').findall(link)

        for eco_url in match:
                eco_url = 'http://www.ecostream.tv/stream/'+eco_url[30:len(eco_url)]
                eco_url = eco_url[0:len(eco_url)-20]+'ss=1'

                req2 = urllib2.Request(eco_url)
                req2.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response2 = urllib2.urlopen(req2)
                link2=response2.read()
                response2.close()

                match2=re.compile("var t=setTimeout\(\"lc\('([^']+)','([^']+)','.+?','.+?'\)\",(.+?)\);").findall(link2)

                for s,k,t in match2:
                        next_url = 'http://www.ecostream.tv/object.php?s='+s+'&k='+k+'&t='+t

                        req3 = urllib2.Request(next_url)
                        req3.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                        response3 = urllib2.urlopen(req3)
                        link3=response3.read()
                        response3.close()

                        match3=re.compile('<param name="flashvars" value="file=(.*?)&').findall(link3)
                        addLink(name,match3[0],path+'/ecostream.jpg')

def ALPHABETICLINKS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()

        match=re.compile('<div class="moviename"><a href="(.+?)" title=".+?">(.+?)</a></div>').findall(link)

        for url,name in match:
            url = 'http://www.kinokiste.com'+url

            req2 = urllib2.Request(url)
            req2.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response2 = urllib2.urlopen(req2)
            link2=response2.read()
            response2.close()

            match2=re.compile('<div class="cover"><img src="(.+?)"').findall(link2)
            thumbnail = 'http://www.kinokiste.com'+match2[0]
            year=re.compile('Jahr: <span style=".+?">(.+?)</span>').findall(link2) 
            name = name+' ('+year[0]+')'

            addDir(name,url,10,thumbnail)

def GENREINDEX(url):
        main_url = url
        req = urllib2.Request(main_url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()

        menu=url[24:len(url)]
        pages=re.compile('&nbsp;</a><a href="'+menu+'(.+?)/"').findall(link)
        pages = int(pages[0])

        for i in range(1, (pages+1)):
            page_url = main_url+str(i)+'/'
            req2 = urllib2.Request(page_url)
            req2.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response2 = urllib2.urlopen(req2)
            link2=response2.read()
            response2.close()        

            match=re.compile('<div class="title">\n\t\t<a href="(.+?)"').findall(link2)

            for url in match:
                url = 'http://www.kinokiste.com'+url
   
                req3 = urllib2.Request(url)
                req3.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response3 = urllib2.urlopen(req3)
                link3=response3.read()
                response3.close()

                match2=re.compile('<div class="cover"><img src="(.+?)" alt="(.+?)"').findall(link3)
                for thumbnail,name in match2:
                    thumbnail = 'http://www.kinokiste.com'+thumbnail
                    year=re.compile('Jahr: <span style=".+?">(.+?)</span>').findall(link3)
                    name = name+' ('+year[0]+')'

                    addDir(name,url,10,thumbnail)
                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL : "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print "CATEGORIES()"
        CATEGORIES()
       
elif mode==1:
        print "INDEX("+url+")"
        INDEX(url)

elif mode==2:
        print "INDEX("+url+")"
        INDEX(url)

elif mode==3:
        print "INDEX("+url+")"
        INDEX(url)

elif mode==4:
        print "INDEX("+url+")"
        INDEX(url)
        
elif mode==5:
        print "ALPHABETICINDEX("+url+")"
        ALPHABETICINDEX(url)

elif mode==6:
        print "GENRES("+url+")"
        GENRESINDEX(url)

elif mode==7:
        print "SEARCH("+url+")"
        SEARCH(url)

elif mode==8:
        print "SEASON("+url+","+name+")"
        SEASON(url,name)

elif mode==9:
        print "EPISODE("+url+","+name+")"
        EPISODE(url,name)

elif mode==10:
        print "VIDEOLINKS("+url+","+name+")"
        VIDEOLINKS(url,name)

elif mode==11:
        print "SERIENLINKS("+url+","+name+")"
        SERIELINKS(url,name)

elif mode==12:
        print "ALPHABETICLINKS("+url+","+name+")"
        ALPHABETICLINKS(url,name)

elif mode==13:
        print "GENRE("+url+")"
        GENREINDEX(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
