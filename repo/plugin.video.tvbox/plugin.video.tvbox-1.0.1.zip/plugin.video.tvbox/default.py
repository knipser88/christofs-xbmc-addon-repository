import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon

#TV Box - by Christof Torres 2012 - 2013.

addon = xbmcaddon.Addon(id='plugin.video.tvbox')
art_path = addon.getAddonInfo('path')+'/resources/art/'

user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

main_url = 'http://www.tv-kino.net'

def TVCHANNELS():
        req = urllib2.Request(main_url)
        req.add_header('User-Agent', user_agent)
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        channels = re.compile('<a title=".+? Online TV Live Stream" href="(.+?)">(.+?)</a>').findall(link)
        number = 0
        for url,name in channels:
                number += 1
                url = main_url+url
                req2 = urllib2.Request(url)
                req2.add_header('User-Agent', user_agent)
                response2 = urllib2.urlopen(req2)
                link2 = response2.read()
                response2.close()
                try:
                        epg = re.compile('<ul class="guidecarousel" style="height: 323px; overflow-y: auto;"><li>(.+?) - (.+?)</li><li>(.+?) - .+?</li>').findall(link2)
                        epg = epg[0][1]+' '+epg[0][0]+' - '+epg[0][2]
                except:
                        epg = ''
                try:
                        flashvars = re.compile('file=(.+?)&amp;.+?streamer=(.+?)&amp;').findall(link2)
                        for playpath,rtmp in flashvars:
                                if (number < 10):
                                        name = '  '+str(number)+' '+name+'       '+epg
                                else:
                                        name = str(number)+' '+name+'       '+epg
                                rtmp = rtmp[0:len(rtmp)-1]
                                link = rtmp+' app=stream swfUrl=http://stream.tv-kino.net/player.swf playpath='+playpath+' live=true'
                                addLink(name,link,art_path+'/'+playpath+'.jpg')
                except:
                        print "Unexpected error: "+url

                        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL : "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print "TVCHANNELS()"
        TVCHANNELS()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
